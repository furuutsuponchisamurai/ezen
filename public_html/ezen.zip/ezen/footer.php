<div class="main-footer">
         <div class="main">
             <div class="content">
                 <div class="section">
                     <div class="row">
                       <div class="col-md-5 footer-column">
                         <h5 class="footer-heading">ABOUT EZEN</h5>
                         <hr class="short-footer">       
                         <p class="footer-color">Ezen Aviation Private Limited is privileged to enjoy a highly experienced and dedicated staff, providing unmatched quality service in meeting our customer’s needs and solving their problems while giving them competitive pricing. Our high standards and attention to detail starts with a strict quality control policy.</p>
                      <!--  <div class="social-network">
                           <div class="social-items"><a href="#"><div class="icon-fa"><i class="fa fa-facebook" aria-hidden="true"></i></div></a></div>
                           <div class="social-items"><a href="#"><div class="icon-fa"><i class="fa fa-twitter" aria-hidden="true"></i></div></a></div>
                           <div class="social-items"><a href="#"><div class="icon-fa"><i class="fa fa-instagram" aria-hidden="true"></i></div></a></div>
                           <div class="social-items"><a href="#"><div class="icon-fa"><i class="fa fa-youtube-play" aria-hidden="true"></i></div></a></div>
                        </div> -->
                       </div>
                       <div class="col-md-3 center-column">
                         <h5 class="footer-heading">CONTACT US</h5>
                         <hr class="short-footer">
                         <div class="footer-location">
                            <div class="location-fa"><i class="fa fa-location-arrow" aria-hidden="true"></i></div>
                             <div class="location-info"><p>10 Zahra, Prof Almeida Road 
															Bandra Mumbai – 400050
															India</p>
								 <div class="location-fa"><i class="fa fa-location-arrow" aria-hidden="true"></i></div>						
															<p>6/259 Albany Creek Road
															  Bridgemandowns
															  Queensland – 4035
															  Australia</p></div>
                         </div>
                         <div class="footer-location">
                            <div class="location-fa"><i class="fa fa-phone" aria-hidden="true"></i></div>
                             <div class="location-info"><p>+91 97699 18555 </p></div>
                             <div class="location-info"><p>+61 4 5187 2512</p></div>
                         </div>
                        <div class="footer-location">
                            <div class="location-fa"><i class="fa fa-envelope" aria-hidden="true"></i></div>
                             <div class="location-info"><p>ncreddy@ezenaviation.com <br>sales@ezenaviation.com</p></div>
                         </div>
                       </div>
                       <div class="col-md-4 footer-column">
                         <h5 class="footer-heading">GALLERY</h5>
                         <hr class="short-footer">
                         <div class="row">
                          <div class="col-xs-3 col-sm-3 col-md-3"><div class="footer-thumbnail"><a href="#"><img src="img/images/autos/imagea.jpg" alt=""></a></div></div>
                          <div class="col-xs-3 col-sm-3 col-md-3"><div class="footer-thumbnail"><a href="#"><img src="img/images/autos/imageb.jpg" alt=""></a></div></div>
                          <div class="col-xs-3 col-sm-3 col-md-3"><div class="footer-thumbnail"><a href="#"><img src="img/images/autos/imagec.jpg" alt=""></a></div></div>
                          <div class="col-xs-3 col-sm-3 col-md-3"><div class="footer-thumbnail"><a href="#"><img src="img/images/autos/imaged.jpg" alt=""></a></div></div>
                          <div class="col-xs-3 col-sm-3 col-md-3"><div class="footer-thumbnail"><a href="#"><img src="img/images/autos/imagee.jpg" alt=""></a></div></div>
                          <div class="col-xs-3 col-sm-3 col-md-3"><div class="footer-thumbnail"><a href="#"><img src="img/images/autos/imagef.jpg" alt=""></a></div></div>
                          <div class="col-xs-3 col-sm-3 col-md-3"><div class="footer-thumbnail"><a href="#"><img src="img/images/autos/imageg.jpg" alt=""></a></div></div>
                          <div class="col-xs-3 col-sm-3 col-md-3"><div class="footer-thumbnail"><a href="#"><img src="img/images/autos/imageh.jpg" alt=""></a></div></div>
                        </div>
                       </div>
                     </div>
                 </div>
             </div>
         </div>   
    </div>
    
    <div class="bottom-footer">
        <div class="main">
            <div class="section">
                <div class="column-left">
                    <p>Designed By<span id="gold"> Pravdakshaya</span></p>
                </div>
                <div class="column-right">
                    <p><span><a href="#">All Copyrights © Rights 2018 Reserved By </a></span><span id="gold">ezenaviation</span></p>
                </div>
            </div>
        </div>
    </div>
    
    <a href="#0" class="cd-top">Top</a>
   


