
        <div class="main-header">
            <!-- MAIN NAVBAR -->
            <div class="main-navbar" >
                  <nav id="mainNav" class="navbar navbar-default navbar-fixed-top" style="background:black;padding:10px;">
                  <!-- <div class="top-header">
                      <div class="container content-top">
                        <div class="leftside">
                            <div class="header-items">
                                <p><i class="fa fa-location-arrow" aria-hidden="true"></i>&nbsp; jubliee hills,Hyderabad</p>
                            </div>
                            <div class="header-items">
                                <p><i class="fa fa-envelope" aria-hidden="true"></i>&nbsp; info@gmail.com</p>
                            </div>
                            <div class="header-items">
                                <p><i class="fa fa-phone" aria-hidden="true"></i>&nbsp;7770007770</p>
                            </div>
                        </div>
                        <div class="rightside">
                            <div class="header-items"><a href="#"><p><i class="fa fa-facebook" aria-hidden="true"></i></p></a></div>
                            <div class="header-items"><a href="#"><p><i class="fa fa-twitter" aria-hidden="true"></i></p></a></div>
                            <div class="header-items"><a href="#"><p><i class="fa fa-instagram" aria-hidden="true"></i></p></a></div>
                            <div class="header-items no-margin"><a href="#"><p><i class="fa fa-youtube-play" aria-hidden="true"></i></p></a></div>
                        </div>
                      </div>
                  </div> -->
                  <div class="container">
                        <div class="navbar-header" >
                          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                          </button>
                          <a class="navbar-brand" href="index"><div class="logo-brand"><img src="img/master/logo.png" style="position: relative; top: -29px;" alt=""></div></a>
                        </div>
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                          <ul class="nav navbar-nav navbar-right" style="margin-top:-10px">
                           <li><a href="index">HOME</a></li>
								<!--<ul class="dropdown-menu">
									<li class="divider-top"></li>
									<li><a href="http://themesquality.com/templates/autochoice/theme1">Home Page 1</a></li>
									<li class="divider"></li>
									<li><a href="http://themesquality.com/templates/autochoice/theme2">Home Page 2</a></li>
									<li class="divider"></li>
									<li><a href="http://themesquality.com/templates/autochoice/theme3">Home Page 3</a></li>
									<li class="divider"></li>
									<li><a href="http://themesquality.com/templates/autochoice/theme4">Home Page 4</a></li>
									<li class="divider"></li>
									<li><a href="http://themesquality.com/templates/autochoice/theme5">Home Page 5</a></li>
									<li class="divider"></li>
									<li><a href="http://themesquality.com/templates/autochoice/theme6">Home Page 6</a></li>
									<li class="divider"></li>
									<li><a href="http://themesquality.com/templates/autochoice/theme7">Home Page 7</a></li>
									<li class="divider"></li>
									<li><a href="http://themesquality.com/templates/autochoice/theme8">Home Page 8</a></li>
								</ul>-->
							
                           <li><a href="about">ABOUT US</a></li>
                                <!--<ul class="dropdown-menu">
                                    <li class="divider-top"></li>
                                    <li><a href="about">About</a></li>
                                    <li class="divider"></li>
                                    <li><a href="careers">Careers</a></li>
                                    <li class="divider"></li>
                                    <li><a href="faq">Faq</a></li>
                                    <li class="divider"></li>
                                    <li><a href="404">404 Page</a></li>
                                    <li class="divider"></li>
                                    <li><a href="team">Team</a></li>
                                    <li class="divider"></li>
                                    <li><a href="coming-soon">Coming Soon</a></li>
                                </ul>-->
                           
                            <li >
                                <a href="services" >SERVICES </a>
                                <!-- <ul class="dropdown-menu">
                                    <li class="divider-top"></li>
                                    <li><a href="services">Services </a></li>
                                    <li class="divider"></li>
                                    <li><a href="services">Services </a></li>
                                </ul> -->
                            </li>
							
                            <li class="dropdown">
                               <li><a href="gallery">GALLERY</a></li>
                               <!-- <ul class="dropdown-menu">
                                    <li class="divider-top"></li>
                                    <li><a href="grid-left-sidebar">Grid Left Sidebar</a></li>
                                    <li class="divider"></li>
                                    <li><a href="grid-right-sidebar">Grid Right Sidebar</a></li>
                                    <li class="divider"></li>
                                    <li><a href="car-details">Car Details</a></li>
                                </ul>-->
                         
                            <!--<li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">ACCESSORIES <span class="caret-drop"></span></a>
                                <ul class="dropdown-menu">
                                    <li class="divider-top"></li>
                                    <li><a href="accesories-left-sidebar">Grid Left Sidebar</a></li>
                                    <li class="divider"></li>
                                    <li><a href="accesories-right-sidebar">Grid Right Sidebar</a></li>
                                    <li class="divider"></li>
                                    <li><a href="accesories-detail">Accesories Details</a></li>
                                    <li class="divider"></li>
                                    <li><a href="shopping-cart">Shopping Cart</a></li>
                                    <li class="divider"></li>
                                    <li><a href="checkout">Checkout</a></li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">BLOG <span class="caret-drop"></span></a>
                                <ul class="dropdown-menu">
                                    <li class="divider-top"></li>
                                    <li><a href="blog-left-sidebar">Left Sidebar</a></li>
                                    <li class="divider"></li>
                                    <li><a href="blog-right-sidebar">Right Sidebar</a></li>
                                    <li class="divider"></li>
                                    <li><a href="blog-single">Blog Single</a></li>
                                </ul>
                            </li>-->
                            <li><a href="contact">CONTACT</a></li>
                          </ul>
                        </div>
                    </div>
                </nav>
            </div><!-- END MAIN NAVBAR -->
        </div><!-- END MAIN HEADER -->