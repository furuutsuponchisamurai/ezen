"use strict";
$(document).ready(function () {
   setTimeout(function () {
     $('#loader-wrapper').fadeOut();
   }, 1200);
});